package app.rpbot;

/** Thin JNI wrapper around the native llama.cpp engine (librpllm.so). */
public final class Llm {
    public interface Callback { void onText(String text); }

    private static boolean loadedLib = false;
    private static String libError = null;

    /** Offline AI needs ARMv8.2 dot-product instructions (practically all phones since 2018). */
    public static synchronized String ensureLibrary() {
        if (loadedLib) return null;
        if (libError != null) return libError;
        try {
            String abi = android.os.Build.SUPPORTED_ABIS.length > 0 ? android.os.Build.SUPPORTED_ABIS[0] : "";
            if (abi.equals("arm64-v8a") && !cpuHasDotProd()) {
                libError = "Процессор этого телефона слишком старый для офлайн-ИИ (нет инструкций ARMv8.2). Используйте онлайн-режим.";
                return libError;
            }
            System.loadLibrary("rpllm");
            loadedLib = true;
            return null;
        } catch (Throwable t) {
            libError = "Офлайн-движок недоступен на этом устройстве: " + t.getMessage();
            return libError;
        }
    }

    static boolean cpuHasDotProd() {
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader("/proc/cpuinfo"))) {
            String line;
            boolean sawFeatures = false;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("Features")) {
                    sawFeatures = true;
                    if (line.contains("asimddp")) return true;
                }
            }
            return !sawFeatures; // unknown format: try anyway
        } catch (Exception e) {
            return true;
        }
    }

    private long handle = 0;

    public synchronized String load(String path, int nCtx, int nThreads) {
        String e = ensureLibrary();
        if (e != null) return e;
        if (handle == 0) handle = nativeCreate();
        return nativeLoad(handle, path, nCtx, nThreads);
    }

    public synchronized void unload() { if (handle != 0) nativeUnload(handle); }

    public String info() { return handle == 0 ? "{\"loaded\":false}" : nativeInfo(handle); }

    public void stop() { if (handle != 0) nativeStop(handle); }

    public int countTokens(String text) { return handle == 0 ? text.length() / 3 : nativeCountTokens(handle, text); }

    public String generate(String[] roles, String[] contents, int nPredict, float temp, float topP, float minP, int topK,
                           float repeatPenalty, String[] stops, String tmpl, Callback cb) {
        if (handle == 0) return "{\"status\":-1,\"error\":\"Модель не загружена\"}";
        return nativeGenerate(handle, roles, contents, nPredict, temp, topP, minP, topK, repeatPenalty, stops, tmpl, cb);
    }

    private static native long nativeCreate();
    private static native void nativeDestroy(long h);
    private static native String nativeLoad(long h, String path, int nCtx, int nThreads);
    private static native void nativeUnload(long h);
    private static native String nativeInfo(long h);
    private static native void nativeStop(long h);
    private static native int nativeCountTokens(long h, String text);
    private static native String nativeGenerate(long h, String[] roles, String[] contents, int nPredict, float temp, float topP,
                                                float minP, int topK, float repeatPenalty, String[] stops, String tmpl, Callback cb);
}
